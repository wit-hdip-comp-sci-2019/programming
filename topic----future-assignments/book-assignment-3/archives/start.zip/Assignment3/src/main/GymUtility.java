public class GymUtility {
}
