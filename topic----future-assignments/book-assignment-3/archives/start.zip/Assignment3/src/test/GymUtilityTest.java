public class GymUtilityTest {
}
