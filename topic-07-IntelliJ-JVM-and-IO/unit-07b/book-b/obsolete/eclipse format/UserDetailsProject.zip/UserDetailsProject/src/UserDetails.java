import java.util.Scanner;

/**
 * This class asks the user to enter their name, address, age and date of birth.  
 * The entered data is then printed out to the user.
 * 
 * @author (WIT) 
 * @version (1.0)
 */

public class UserDetails
{
	public static void main(String[] arg)
	{ 
		//variables 
		Scanner sc = new Scanner(System.in);   
		String name;
		String address;
		String dateOfBirth;
		int age;

		//obtaining the data from the user
		System.out.println("Entering details");
		System.out.println("----------------");
		System.out.print("   Enter your name:          ");
		name = sc.nextLine();         
		System.out.print("   Enter your address:       ");
		address = sc.nextLine();
		System.out.print("   Enter your date of birth: ");
		dateOfBirth = sc.nextLine();
		System.out.print("   Enter your age:           ");
		age = sc.nextInt();
		System.out.println();

		//printing out the data to the user
		System.out.println("Printing details");
		System.out.println("----------------");
		System.out.println("   Your name is:     " + name);  
		System.out.println("   Your address is:  " + address);
		System.out.println("   You were born on: " + dateOfBirth);
		System.out.println("   Your age is:      " + age);
	}        
}
