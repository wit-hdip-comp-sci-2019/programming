import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("Tests for Stpre class")
public class StoreTest {
    Store store;
    Product product1;
    Product product2;
    Product product3;
    Product product4;

    @BeforeEach
    public void setUp() {
        store = new Store();
        product1 = new Product("Product A", 1, 10.0, true);
        product2 = new Product("Product B", 2, 10.0, true);
        product3 = new Product("Product C", 3, 10.0, true);
        product4 = new Product("Product D", 4, 10.0, true);
    }

    @Nested
    @DisplayName("List products")
    class List {

        @Nested
        @DisplayName("Given their are products in the store")
        class Valid {

            @DisplayName("Should return string with details of each one")
            @ParameterizedTest(
                    name = "Products currently in the store: {0}, {1} and {2} ")
            @CsvSource({
                    "Product A, Product B , Product C"})
            public void listThem(String a, String b, String c) {
                store.add(product1);
                store.add(product2);
                store.add(product3);
                String result = store.listProducts();
                assertTrue(result.contains(a), a + " was not in the result");
                assertTrue(result.contains(b), b + " was not in the result");
                assertTrue(result.contains(c), c + " was not in the result");
            }

        }

        @Nested
        @DisplayName("Given the store has no products")
        class Invalid {

            @Test
            @DisplayName("Should return the empty store message")
            public void listThem() {
                String result = store.listProducts();
                assertEquals("NO PRODUCTS", result.toUpperCase(),
                        "Incorrect message returned");
            }

        }
    }

    @Nested
    @DisplayName("Find the cheapest product")
    class Cheapest {

        @Nested
        @DisplayName("Given their are products in the store")
        class Valid {

            @BeforeEach
            public void setUp() {
                store.add(product1);
                store.add(product2);
                store.add(product3);
                store.add(product4);
            }

            @DisplayName("When the cheapest is the first one")
            @Test
            public void first() {
                product1.setUnitCost(9);
                String result = store.cheapestProduct();
                assertEquals("Product A", result, "Did not return the cheapest");
            }

            @DisplayName("When the cheapest is the last one")
            @Test
            public void last() {
                product4.setUnitCost(9);
                String result = store.cheapestProduct();
                assertEquals("Product D", result, "Did not return the cheapest");
            }

            @DisplayName("When the cheapest is inside the array boundaries.")
            @Test
            public void middle() {
                product3.setUnitCost(9);
                String result = store.cheapestProduct();
                assertEquals("Product C", result, "Did not return the cheapest");
            }
        }

        @Nested
        @DisplayName("Given the store is empty")
        class Invalid {

            @Test
            @DisplayName("Should retun the empty store message")
            public void listThem() {
                String result = store.cheapestProduct();
                assertTrue(result.contains("No Products"), "Incorrect message returned");
            }

        }
    }

    @Nested
    @DisplayName("Find the products currently in stock")
    class CurrentStock {

        @Nested
        @DisplayName("Given their are products in the array")
        class arrayPopulated {

            @BeforeEach
            public void setUp() {
                store.add(product1);
                store.add(product2);
                store.add(product3);
                store.add(product4);
            }

            @Nested
            @DisplayName("But all are currently out of stock")
            class NoStock {

                @BeforeEach
                public void setUp() {
                    product1.setInCurrentProductLine(false);
                    product2.setInCurrentProductLine(false);
                    product3.setInCurrentProductLine(false);
                    product4.setInCurrentProductLine(false);
                }

                @DisplayName("Should return an empty string")
                @Test
                public void list() {
                    String result = store.listCurrentProducts();
                    assertEquals("", result, "Did not return an empty string");
                }

            }

            @Nested
            @DisplayName("When some are currently in stock")
            class SomeStock {

                @BeforeEach
                public void setUp() {
                    product2.setInCurrentProductLine(false);
                    product4.setInCurrentProductLine(false);
                }

                @DisplayName("Should return string with their names")
                @Test
                public void list() {
                    String result = store.listCurrentProducts();
                    assertTrue(result.contains("Product A") &&
                                    result.contains("Product C"),
                            "Returned string does not have correct producys");
                }
            }
        }

        @Nested
        @DisplayName("Given the store's product array is empty")
        class Empty {

            @Test
            @DisplayName("Should return the empty store message")
            public void listThem() {
                String result = store.cheapestProduct();
                assertTrue(result.contains("No Products"), "Incorrect message returned");
            }

        }
    }

    @Nested
    @DisplayName("Compute the average product price")
    class ComputeAverage {

        @Nested
        @DisplayName("Given their are products in the array")
        class arrayPopulated {

            @BeforeEach
            public void setUp() {
                store.add(product1);
                store.add(product2);
                store.add(product3);
                store.add(product4);
            }

            @DisplayName("Should return the average price")
            @Test
            public void compute() {
                double result = store.averageProductPrice();
                assertEquals(10.0, result,
                        "Incorrect calculation");
            }
        }

        @Nested
        @DisplayName("Given the store's product array is empty")
        class Empty {

            @Test
            @DisplayName("Should return 0.0 as the average")
            public void compute() {
                double result = store.averageProductPrice();
                assertEquals(0.0, result, "Did not returm 0.0");
            }
        }
    }

}
