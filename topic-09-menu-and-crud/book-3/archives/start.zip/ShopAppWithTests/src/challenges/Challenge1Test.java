import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("Tests for Challenge 1")
public class Challenge1Test {
    Store store;
    Product product1;
    Product product2;
    Product product3;
    Product product4;

    @BeforeEach
    public void setUp() {
        store = new Store();
        product1 = new Product("Product A", 1, 10.0, true);
        product2 = new Product("Product B", 2, 10.0, true);
        product3 = new Product("Product C", 3, 10.0, true);
        product4 = new Product("Product D", 4, 10.0, true);
    }

    @Nested
    @DisplayName("Compute total value of products in stock")
    class AddUnique {

        @Nested
        @DisplayName("Given their are products in the array")
        class ArrayPopulated {

            @BeforeEach
            public void setUp() {
                store.add(product1);
                store.add(product2);
                store.add(product3);
                store.add(product4);
            }

            @Nested
            @DisplayName("and some are in the current product line ")
            class SomeCurrent {

                @BeforeEach
                public void setUp() {
                    product1.setInCurrentProductLine(false);
                }

                @DisplayName("Should return the total price")
                @Test
                public void compute() {
                    double result = store.totalValue();
                    assertEquals(30.0, result,
                            "Incorrect calculation");
                }
            }

            @Nested
            @DisplayName("but none are in the current product line ")
            class NoneCurrent {

                @BeforeEach
                public void setUp() {
                    product1.setInCurrentProductLine(false);
                    product2.setInCurrentProductLine(false);
                    product3.setInCurrentProductLine(false);
                    product4.setInCurrentProductLine(false);
                }
                @DisplayName("Should return 0.0")
                @Test
                public void compute() {
                    double result = store.totalValue();
                    assertEquals(0.0, result,
                            "Did not return 0.0");
                }
            }
        }

        @Nested
        @DisplayName("Given the store's product array is empty")
        class Empty {

            @Test
            @DisplayName("Should return 0.0.")
            public void compute() {
                double result = store.totalValue();
                assertEquals(0.0, result, "Did not returm 0.0");
            }
        }
    }
}
