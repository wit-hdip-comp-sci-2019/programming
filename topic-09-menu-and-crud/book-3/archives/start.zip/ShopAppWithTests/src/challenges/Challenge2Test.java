
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("Tests for Challenge 2")
public class Challenge2Test {
    Store store;
    Product product1;
    Product product2;
    Product product3;
    Product product4;

    @BeforeEach
    public void setUp() {
        store = new Store();
        product1 = new Product("Product A", 1, 10.0, true);
        product2 = new Product("Product B", 2, 10.0, true);
        product3 = new Product("Product C", 3, 10.0, true);
        product4 = new Product("Product D", 4, 10.0, true);
    }

    @Nested
    @DisplayName("Add unique product to stock")
    class AddUnique {

        @BeforeEach
        public void setUp() {
            store.add(product1);
            store.add(product2);
            store.add(product3);
            store.add(product4);
        }

        @DisplayName("When the new product's code is unique")
        @Test
        public void unique() {
            Product newProduct = new Product("Product D",
                    5, 10.0,
                    true);
            int result = store.addUniqueProduct(newProduct );
            assertEquals(4, result,
                    "Incorrect index returned");
        }

        @DisplayName("When the new product's code is not unique")
        @Test
        public void notUnique() {
            Product newProduct = new Product("Product D",
                    2, 10.0,
                    true);
            int result = store.addUniqueProduct(newProduct );
            assertEquals(-1, result,
                    "Should return -1");
        }
    }
}
